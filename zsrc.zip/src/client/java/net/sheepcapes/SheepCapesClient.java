package net.sheepcapes;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Точка входа клиента мода SheepCapes.
 */
public class SheepCapesClient implements ClientModInitializer {

    public static final String MOD_ID = "sheepcapes";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Имя игрока, чьи плащи нужно показать (ставится при клике по нику). */
    private static volatile String pendingPlayerName = null;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[SheepCapes] клиент инициализирован");

        // Регистрируем кастомный C2S-плагин для запроса списка плащей у сервера
        CapeBackend.registerPayloadChannel();

        // Открываем GUI на следующем тике клиента, когда клик будет обработан ваниллой
        MinecraftClient.getInstance().tickEvents.add(tick -> {
            String name = pendingPlayerName;
            if (name != null) {
                pendingPlayerName = null;
                openCapeScreen(name);
            }
        });
    }

    /** Вызывается из миксина Tab-листа и из обработчика кликов чата. */
    public static void onPlayerNameClicked(String playerName) {
        LOGGER.info("[SheepCapes] клик по нику: {}", playerName);
        pendingPlayerName = playerName;
    }

    private static void openCapeScreen(String playerName) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null) return;

        java.util.UUID uuid = CapeBackend.lookupUuid(playerName);
        java.util.List<CapeData> capes = CapeBackend.fetchCapes(uuid, playerName);

        client.setScreen(new CapesScreen(Text.literal("Плащи игрока: " + playerName), capes));
    }

    /** Текст ника с ClickEvent — используется и в миксине Tab-листа, и в чате. */
    public static Text clickableName(String playerName) {
        return Text.literal(playerName)
                .styled(style -> style
                        .withClickEvent(new ClickEvent(
                                ClickEvent.Action.SUGGEST_COMMAND,
                                "/sheepcapes view " + playerName))
                        .withUnderline(true));
    }
}
