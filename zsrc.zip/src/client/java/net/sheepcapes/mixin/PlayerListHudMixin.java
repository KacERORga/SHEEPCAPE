package net.sheepcapes.mixin;

import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.sheepcapes.SheepCapesClient;

/**
 * Самый надёжный вариант перехвата клика по нику в Tab-листе:
 * вместо ручного трекинга координат мыши подменяем результат метода
 * getPlayerName(PlayerListEntry) — ник оборачивается в Text с ClickEvent.
 * Minecraft сам обрабатывает Ctrl+Click по любому тексту HUD/чата.
 * Для открытия GUI используется Action.RUN_COMMAND с клиентским
 * slash-командом /sheepcapes view <name>, зарегистрированным в SheepCapesClient.
 */
@Mixin(PlayerListHud.class)
public abstract class PlayerListHudMixin {

    @Inject(method = "getPlayerName", at = @At("RETURN"), cancellable = true)
    private void sheepcapes$makeNameClickable(PlayerListEntry entry,
                                              CallbackInfoReturnable<Text> cir) {
        Text original = cir.getReturnValue();
        if (original == null) return;

        String name = entry.getProfile().getName();
        if (name == null || name.isEmpty()) return;

        MutableText clickable = original.copy();
        clickable.setStyle(
                clickable.getStyle()
                        .withClickEvent(new ClickEvent(
                                ClickEvent.Action.RUN_COMMAND,
                                "/sheepcapes view " + name))
                        .withUnderline(true));

        SheepCapesClient.LOGGER.debug("[SheepCapes] ник {} сделан кликабельным", name);
        cir.setReturnValue(clickable);
    }
}
