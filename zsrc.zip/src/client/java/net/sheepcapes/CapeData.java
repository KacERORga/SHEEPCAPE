package net.sheepcapes;

import java.util.UUID;

/**
 * Данные одного плаща игрока.
 *
 * @param id     внутренний идентификатор плаща
 * @param name   отображаемое название
 * @param textureUrl абсолютный URL PNG-текстуры плащи (128x64)
 */
public record CapeData(String id, String name, String textureUrl) {
}
